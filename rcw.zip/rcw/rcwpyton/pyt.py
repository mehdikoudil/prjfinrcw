from flask import Flask, request, jsonify, redirect, url_for
import requests

app = Flask(__name__)

@app.route('/reception', methods=['POST'])
def reception():
    if request.method == 'POST':
        data = request.json  # Récupérer les données JSON de la requête
        print('Données reçues:', data)

        # Calculer le montant avec la taxe
        montant_avec_taxe = data['montant'] * 0.15

        # Ajouter la nouvelle variable au dictionnaire de données
        data['montant_avec_taxe'] = montant_avec_taxe

        # Envoyer les données à un script PHP
        phpurl = 'http://localhost:8000/rcwlab1/result.php'  # Adapt to your PHP script URL
        response = requests.post(phpurl, json=data)

        if response.status_code == 200:
            print('Réponse du script PHP:', response.text)
            return redirect(url_for('success'))
        else:
            return jsonify({'error': 'Une erreur s\'est produite lors de l\'envoi des données au script PHP.'}), 500
    else:
        return 'Méthode non autorisée', 405

@app.route('/success')
def success():
    return 'Données envoyées avec succès au script PHP.'

if __name__ == '__main__':
    app.run(debug=True, port=4000)
