const http = require('http');
const querystring = require('querystring');
const axios = require('axios'); // Ajout du module axios pour les requêtes HTTP

const server = http.createServer((req, res) => {
    if (req.method === 'POST') {
        let data = '';
        req.on('data', (chunk) => {
            data += chunk.toString();
        });

        req.on('end', () => {
            const parsedData = querystring.parse(data);

            // Calculer le montant en multipliant le prix par la quantité
            const montant = parsedData.prix * parsedData.quantite;

            // Ajouter la nouvelle variable au tableau de données
            parsedData.montant = montant;

            // Afficher les données reçues dans la console
            console.log('Données reçues :', parsedData);

            // Envoyer les données à un autre fichier ou une autre API
            axios.post('http://localhost:4000/reception', parsedData)
                .then(response => {
                    console.log('Réponse du serveur distant :', response.data);
                })
                .catch(error => {
                    console.error('Erreur lors de l\'envoi des données :', error);
                });

            res.writeHead(200, { 'Content-Type': 'text/plain' });
            res.end('Données reçues avec succès !');
        });
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Erreur 404: Page non trouvée');
    }
});

const port = 3000;

server.listen(port, () => {
    console.log(`Serveur démarré sur http://localhost:${port}`);
});
