from skimage.feature import graycomatrix, graycoprops
import mahotas.features as features
import cv2

def glcm(img):
    # img is already an image array, no need to read it again
    co_matrix = graycomatrix(img, [2], [0], None, symmetric=True, normed=True)
    diss = graycoprops(co_matrix, 'dissimilarity')[0, 0]
    cont = graycoprops(co_matrix, 'contrast')[0, 0]
    corr = graycoprops(co_matrix, 'correlation')[0, 0]
    ener = graycoprops(co_matrix, 'energy')[0, 0]
    homo = graycoprops(co_matrix, 'homogeneity')[0, 0]
    return [diss, cont, corr, ener, homo]

def bitdesc(img):
    return bio_taxo(img)

def haralick(img): 
    main_data = features.haralick(img).mean(0)
    result_list = []
    for main in main_data:
        result_list.append(main.tolist())
    return result_list
