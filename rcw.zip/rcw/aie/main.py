import streamlit as st
from Imagery import run_imagery
from predictDiag import run_predict_diag
from ChatPdf import run_chat_pdf

# Set the page config at the very beginning of the main script
st.set_page_config(page_title="MediCareTeccart Applications", page_icon=":hospital:", layout="centered")

def run_home():
    st.image("logo.png", width=200)  # Ensure logo.png is present in the same directory
    st.title("Welcome to MediCareTeccart")

    st.markdown("""
        <h2 style="color:##00796b;">Explore Our Applications</h2>
        <p style="color:##00796b; font-size: 18px;">
            MediCareTeccart offers a suite of tools to assist with medical diagnostics, symptom checking, and more. 
            Select one of the applications below to get started:
        </p>
        <ul style="list-style-type:none; padding: 0;">
            <li style="margin: 20px 0;"><a href="#" style="color: #de7878; font-size: 24px;" onclick="window.location.href='/Imagery Analysis'">Imagery Analysis</a></li>
            <li style="margin: 20px 0;"><a href="#" style="color: #de7878; font-size: 24px;" onclick="window.location.href='/Predict Disease'">Predict Disease</a></li>
            <li style="margin: 20px 0;"><a href="#" style="color: #de7878; font-size: 24px;" onclick="window.location.href='/Chat PDF'">Chat PDF</a></li>
        </ul>
        <p style="color:##004d40;">Developed by MediTeccart © 2024</p>
    """, unsafe_allow_html=True)

def main():
    st.sidebar.title("Navigation")
    app = st.sidebar.radio("Go to", ["Home", "Imagery Analysis", "Predict Disease", "Chat PDF"])

    if app == "Home":
        run_home()
    elif app == "Imagery Analysis":
        run_imagery()
    elif app == "Predict Disease":
        run_predict_diag()
    elif app == "Chat PDF":
        run_chat_pdf()

if __name__ == '__main__':
    main()
