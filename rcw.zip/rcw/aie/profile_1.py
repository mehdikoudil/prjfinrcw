from PyPDF2 import PdfReader

def extract_text_from_pdf(pdf_doc):
    text = ""
    pdf_reader = PdfReader(pdf_doc)
    for page in pdf_reader.pages:
        text += page.extract_text()
    return text

# Example usage
path = 'summary.pdf'
profile_text = extract_text_from_pdf(path)
print(profile_text)
