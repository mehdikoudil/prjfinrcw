import streamlit as st
import numpy as np
from PIL import Image
from sklearn.metrics.pairwise import cosine_similarity
from descriptors import glcm  # Assuming this is the same GLCM function you used

def imagery_about():
    st.sidebar.info(
        "À propos\n\n"
        "Cette application analyse les images médicales pour diagnostiquer des conditions telles que le Covid-19, "
        "la rétinopathie diabétique, et le glaucome.\n\n"
        "Elle utilise des signatures d'images pour comparer les images téléchargées et fournir un diagnostic potentiel.\n\n"
        "Les résultats ne sont qu'une aide au diagnostic et ne remplacent pas une consultation médicale professionnelle."
    )


def load_image(image_file):
    img = Image.open(image_file)
    img = img.convert('L')  # Convert to grayscale for GLCM
    return np.array(img)

def load_signatures(dataset):
    if dataset == "Covid":
        return np.load('signatures_covid.npy', allow_pickle=True)
    elif dataset == "Diabetic retinopathy":
        return np.load('signatures_diabret.npy', allow_pickle=True)
    elif dataset == "Glaucoma":
        return np.load('signatures_glaucoma.npy', allow_pickle=True)

def extract_features(image_array):
    return glcm(image_array)

def display_disease_information(dataset):
    if dataset == "Covid":
        st.subheader("Description de la maladie : Covid-19")
        st.write("""
            **Symptômes:** Fièvre, toux sèche, fatigue, perte du goût ou de l'odorat, maux de tête.
            
            **Personnes à risque:** Personnes âgées, individus ayant des maladies chroniques telles que le diabète, les maladies cardiaques, ou les maladies respiratoires.
            
            **Recommandations médicales:** Isolement, repos, hydratation, consultation médicale si les symptômes s'aggravent.
        """)
    elif dataset == "Diabetic retinopathy":
        st.subheader("Description de la maladie : Rétinopathie diabétique")
        st.write("""
            **Symptômes:** Vision floue, taches sombres ou vides dans le champ de vision, perte de vision.
            
            **Personnes à risque:** Personnes atteintes de diabète, en particulier celles ayant un diabète mal contrôlé.
            
            **Recommandations médicales:** Contrôle strict de la glycémie, examens réguliers des yeux, traitement laser ou injections intraoculaires selon les cas.
        """)
    elif dataset == "Glaucoma":
        st.subheader("Description de la maladie : Glaucome")
        st.write("""
            **Symptômes:** Perte de vision périphérique, vision tunnel, douleur oculaire, maux de tête.
            
            **Personnes à risque:** Personnes âgées de plus de 60 ans, antécédents familiaux de glaucome, personnes souffrant de diabète ou d'hypertension.
            
            **Recommandations médicales:** Utilisation régulière de collyres pour réduire la pression intraoculaire, examens réguliers de la vue, chirurgie dans les cas avancés.
        """)

def run_imagery():
    imagery_about()

    st.image("logo.png", width=150)  # Smaller logo with fixed width
    st.title("Medical Image Analysis Application")
    st.sidebar.info("")
    st.markdown("""
        <h3 style="color:#de7878;">Instructions</h3>
        <p style="color:#de7878;">Follow these steps:</p>
        <ol style="color:#de7878;">
            <li>Select the dataset you want to use (Covid, Diabetic retinopathy, or Glaucoma) from the dropdown below.</li>
            <li>Upload an image (X-ray for Covid, eye image for Diabetic retinopathy or Glaucoma).</li>
            <li>Click the <b>Predict</b> button to get a diagnosis.</li>
            <li>Use the <b>Reload</b> button to reset the app.</li>
        </ol>
    """, unsafe_allow_html=True)

    dataset = st.selectbox("Choose Dataset", ["", "Covid", "Diabetic retinopathy", "Glaucoma"])

    if dataset:
        display_disease_information(dataset)
        signatures = load_signatures(dataset)
        st.write(f"**Dataset Loaded:** {dataset}")

        uploaded_file = st.file_uploader("Upload an Image", type=["png", "jpeg", "jpg", "bmp"], key="uploaded_file")

        if uploaded_file is not None:
            st.image(uploaded_file, caption="Uploaded Image", use_column_width=True)
            image_array = load_image(uploaded_file)
            image_features = extract_features(image_array)

            col1, col2 = st.columns([1, 1])

            with col1:
                if st.button("Predict"):
                    if signatures is not None:
                        stored_features = signatures[:, :-2].astype(float)
                        labels = signatures[:, -2]

                        similarity_scores = cosine_similarity([image_features], stored_features)
                        most_similar_index = np.argmax(similarity_scores)
                        predicted_label = labels[most_similar_index]

                        st.write(f"**Predicted Class:** {predicted_label}")
                        st.write(f"**Similarity Score:** {similarity_scores[0, most_similar_index]:.2f}")

            with col2:
                if st.button("Reload"):
                    for key in st.session_state.keys():
                        del st.session_state[key]
                    st.experimental_rerun()

    st.markdown("---")
    st.markdown("Developed by MediTeccart © 2024")

