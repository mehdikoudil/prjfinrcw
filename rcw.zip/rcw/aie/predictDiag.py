import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import streamlit as st
from PIL import Image
import snowflake_manipulation as sfm
from datetime import datetime

def run_predict_diag():
    # Initialize session state variables
    def reset_session_state():
        st.session_state['want_appointment'] = False
        st.session_state['disease_predicted'] = False
        st.session_state['predicted_disease'] = ""

    if 'want_appointment' not in st.session_state:
        reset_session_state()

    # Download nltk resources
    nltk.download('punkt')
    nltk.download('stopwords')

    # Load the dataset
    data = pd.read_csv('data/Symptom2Disease.csv') 
    data.drop(columns=["Unnamed: 0"], inplace=True)

    def load_disease_descriptions():
        descriptions_df = pd.read_csv('data/Disease_Descriptions.csv')
        return descriptions_df.set_index('Disease')['Description'].to_dict()

    disease_descriptions = load_disease_descriptions()

    def load_disease_precaution():
        precaution_df = pd.read_csv('data/Disease_Precautions_Advice.csv')
        return precaution_df.set_index('Disease')['Precaution'].to_dict()

    disease_precautions = load_disease_precaution()

    # Extracting 'label' and 'text' columns from the 'data' DataFrame
    labels = data['label']  
    symptoms = data['text'] 

    # Text Preprocessing
    stop_words = set(stopwords.words('english'))

    # Text Preprocessing Function
    def preprocess_text(text):
        words = word_tokenize(text.lower())
        words = [word for word in words if word.isalpha() and word not in stop_words]
        return ' '.join(words)

    # Apply preprocessing to symptoms
    preprocessed_symptoms = symptoms.apply(preprocess_text)

    # Feature Extraction using TF-IDF
    tfidf_vectorizer = TfidfVectorizer(max_features=1500) 
    tfidf_features = tfidf_vectorizer.fit_transform(preprocessed_symptoms).toarray()

    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(tfidf_features, labels, test_size=0.2, random_state=42)

    # KNN Model Training
    knn_classifier = KNeighborsClassifier(n_neighbors=5) 
    knn_classifier.fit(X_train, y_train)

    # Streamlit application layout
    st.title('🔍 Assistant au Diagnostique')
    st.markdown("""
        <style>
        .main-header {
            color: #00796b;
        }
        .prediction-section {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        </style>
    """, unsafe_allow_html=True)

    # Sidebar
    st.sidebar.header("About")
    st.sidebar.info("""
    Cette application est conçue pour aider à prédire les maladies en fonction des symptômes saisis par l'utilisateur.
    Elle utilise des algorithmes d'apprentissage automatique pour analyser les symptômes et fournir un diagnostic possible.
    Il s'agit toujours d'une prédiction et non d'un résultat final. Vous pourriez avoir besoin de tests supplémentaires
    avec un spécialiste.
    """)

    # Main content
    st.header("Entrez vos symptomes")
    user_input = st.text_area("", height=150)

    st.header("Diagnostique Possible")
    predict_button = st.button('Predict Disease')
    
    if predict_button or st.session_state['disease_predicted']:
        st.session_state['disease_predicted'] = True
        
        if user_input == "":
            st.info('Veuillez entrer vos symptômes.')
        else:    
            if predict_button:
                preprocessed_input = preprocess_text(user_input)
                input_vectorized = tfidf_vectorizer.transform([preprocessed_input])
                predicted_disease = knn_classifier.predict(input_vectorized)
                st.session_state['predicted_disease'] = predicted_disease[0]
                
            st.success(f'En fonction de vos symptômes, il est probable que vous ayez: {st.session_state["predicted_disease"]}')
            
            if st.session_state["predicted_disease"] in disease_descriptions and st.session_state["predicted_disease"] in disease_precautions:
                st.subheader('Description de la maladie : ')
                st.info(disease_descriptions[st.session_state["predicted_disease"]])
                st.subheader('Précaution et conseils : ')
                st.info(disease_precautions[st.session_state["predicted_disease"]])
            else:
                st.error("Pas de descriptions ou de conseils pour cette maladie.")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("Voulez-vous un RDV avec un spécialiste?"):
                    st.session_state['want_appointment'] = True
            
            with col2:
                if st.button("Non, merci!"):
                    reset_session_state()
                    st.success("Prompt rétablissement! 🌟")
            
            if st.button("Retour"):
                reset_session_state()
                st.experimental_rerun()
    
    else:
        st.write("La prédiction de votre diagnostic apparaîtra ici.")                

    if st.session_state['want_appointment']:
        st.subheader("Détails du rendez-vous")

        # Get specialists list
        specialists_df = pd.read_csv('data/Medical_Specialists.csv')
        filtered_specialists = specialists_df[specialists_df['Speciality'] == st.session_state['predicted_disease']]
        specialists_list = filtered_specialists["Name"].tolist()
        
        # Display specialists in cards
        for index, specialist in filtered_specialists.iterrows():
            with st.container():
                st.markdown(f"""
                    <style>
                    .card {{
                        margin: 10px;
                        padding: 10px;
                        border-radius: 10px;
                        border: 1px solid #E1E1E1;
                        box-shadow: 2px 2px 12px rgba(0, 0, 0, 0.1);
                    }}
                    </style>
                    <div class="card">
                        <h4>{specialist["Name"]}</h4>
                        <p><b>Specialité:</b> {specialist["Speciality"]}</p>
                        <p><b>Adresse:</b> {specialist["Office Address"]}</p>
                        <p><b>Téléphone:</b> {specialist["Phone Number"]}</p>
                        <p><b>Années d'expérience:</b> {specialist["Years of Experience"]}</p>
                        <p><b>Diplômé de:</b> {specialist["Med School"]}</p>
                    </div>
                """, unsafe_allow_html=True)
        
        # Select a specialist
        selected_specialist = st.selectbox("Sélectionner un spécialiste", specialists_list)
        
        # Patient details input
        patient_name = st.text_input("Votre Nom")
        patient_age = st.number_input("Votre Age", step=1, min_value=0)
        patient_address = st.text_input("Votre Adresse")
        patient_email = st.text_input("Votre Email")
        patient_phone = st.text_input("Votre Numéro de téléphone")
        
        # Appointment date
        appointment_date = st.date_input("Date du rendez-vous", min_value=datetime.today())
        
        # Confirm button
        if st.button("Confirmer le rendez-vous"):
            patient_data = (patient_name, patient_age, patient_address, patient_email, st.session_state['predicted_disease'], patient_phone)

            # Insert patient data and retrieve ID
            sfm.insert_patient_data(patient_data)
            patient_id = sfm.retrieve_patient_id(patient_email)
            
            # Prepare and insert appointment data
            if patient_id:
                appointment_data = (patient_id, appointment_date, selected_specialist)
                sfm.insert_appointment_data(appointment_data)
                st.success(f"Rendez-vous confirmé avec {selected_specialist}")
            else:
                st.error("Erreur : ID du patient introuvable")

    # Footer
    st.markdown("---")
    st.markdown("© 2024 Disease Symptom Checker. By MediTeccart. Tous droits réservés.")
