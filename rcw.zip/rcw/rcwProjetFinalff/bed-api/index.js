const express = require('express');
const mongoose = require('mongoose');
const bedRoutes = require('./routes/bedRoutes');
const app = express();
const PORT = process.env.PORT || 3005;
const cors = require('cors');

app.use(cors());
app.use(express.json());

const uri = "mongodb+srv://wafid:wafid@ouafid.aihn5iq.mongodb.net/RCW";

mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Error connecting to MongoDB', err));


app.use('/api/beds', bedRoutes);

app.listen(PORT, () => {
    console.log(`Bed API running on port ${PORT}`);
});
