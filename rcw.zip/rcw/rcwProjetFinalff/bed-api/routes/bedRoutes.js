const express = require('express');
const bedController = require('../controllers/bedController');
const router = express.Router();

// Routes pour gérer les lits
router.post('/', bedController.assignBed);
router.get('/availability', bedController.checkAvailability);

module.exports = router;
