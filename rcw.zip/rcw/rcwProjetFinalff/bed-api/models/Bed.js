const mongoose = require('mongoose');

const bedSchema = new mongoose.Schema({
    idDoctor: String,
    idClient: Number,
    chambre: String,
    numLit: Number,
    arrivee: Date,
    depart: Date,
    occupied: Boolean,
});

module.exports = mongoose.model('Bed', bedSchema);
