const Bed = require('../models/Bed');

exports.assignBed = async (req, res) => {
    try {
        const bed = new Bed(req.body);
        console.log(bed);
        
        await bed.save();
        res.status(201).json(bed);
    } catch (error) {
        res.status(500).json({ message: 'Error assigning bed', error });
    }
};

exports.checkAvailability = async (req, res) => {
    try {
        const beds = await Bed.find({ occupied: false });
        res.status(200).json(beds);
    } catch (error) {
        res.status(500).json({ message: 'Error checking bed availability', error });
    }
};
