const express = require('express');
const mongoose = require('mongoose');
const doctorRoutes = require('./routes/doctorRoutes');
const app = express();
const PORT = process.env.PORT || 3002;
const cors = require('cors');

app.use(cors());
app.use(express.json());

const uri = "mongodb+srv://wafid:wafid@ouafid.aihn5iq.mongodb.net/RCW";

mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Error connecting to MongoDB', err));
app.use('/api/doctors', doctorRoutes);

app.listen(PORT, () => {
    console.log(`Doctor API running on port ${PORT}`);
});
