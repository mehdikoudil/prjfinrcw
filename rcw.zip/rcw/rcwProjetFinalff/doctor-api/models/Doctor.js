const mongoose = require('mongoose');

const doctorSchema = new mongoose.Schema({
    Name: String,
    FamilyName: String,
    Specialite: String,
    Tel: String,
    Email: String, // Assurez-vous que l'email est unique
    Password: String,
    Role: String
});

module.exports = mongoose.model('Doctor', doctorSchema);
