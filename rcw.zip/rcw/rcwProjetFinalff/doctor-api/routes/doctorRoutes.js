const express = require('express');
const doctorController = require('../controllers/doctorController');
const router = express.Router();

// Routes pour gérer les médecins
router.post('/register', doctorController.registerDoctor);
router.post('/login', doctorController.loginDoctor);
router.get('/profile/:id', doctorController.getDoctorProfile);
router.put('/profile/:id', doctorController.updateDoctorProfile);
router.get('/medical-records/:id', doctorController.getDoctorMedicalRecords);
router.get('/all', doctorController.getAllDoctors);

module.exports = router;
