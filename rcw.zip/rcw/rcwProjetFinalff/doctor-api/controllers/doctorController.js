const Doctor = require('../models/Doctor');
const MedicalRecord = require('../../medical-record-api/models/MedicalRecord');

exports.registerDoctor = async (req, res) => {
    try {
        // Extraire les données du corps de la requête
        const { Name, FamilyName, Specialite, Tel, Email, Password, Role } = req.body;
        console.log(Name, FamilyName, Specialite, Tel, Email, Password, Role);

        // Vérifier que tous les champs nécessaires sont présents
        // if (!Name || !FamilyName || !Specialite || !Tel || !Email || !Password || !Role) {
        //     return res.status(400).json({ message: 'All fields are required' });
        // }

        // Vérifier si le Doctor avec cet email existe déjà
        const existingDoctor = await Doctor.findOne({ Email });
        if (existingDoctor) {
            return res.status(400).json({ message: 'Doctor with this email already exists' });
        }

        // Créer un nouveau Doctor
        const doctor = new Doctor({ Name, FamilyName, Specialite, Tel, Email, Password, Role });
        await doctor.save();
        res.status(201).json(doctor);
    } catch (error) {
        console.error('Error registering doctor:', error);
        res.status(500).json({ message: 'Error registering doctor', error });
    }
};

exports.loginDoctor = async (req, res) => {
    try {
        const { Email, Password } = req.body;
        const doctor = await Doctor.findOne({ Email: Email, Password: Password });
        if (!doctor) {
            return res.status(404).json({ message: 'Doctor not found' });
        }
        res.status(200).json(doctor);
    } catch (error) {
        res.status(500).json({ message: 'Error logging in', error });
    }
};

exports.getDoctorProfile = async (req, res) => {
    try {
        const doctor = await Doctor.findById(req.params.id);
        if (!doctor) {
            return res.status(404).json({ message: 'Doctor not found' });
        }
        res.status(200).json(doctor);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching doctor profile', error });
    }
};

exports.updateDoctorProfile = async (req, res) => {
    try {
        const doctor = await Doctor.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!doctor) {
            return res.status(404).json({ message: 'Doctor not found' });
        }
        res.status(200).json(doctor);
    } catch (error) {
        res.status(500).json({ message: 'Error updating doctor profile', error });
    }
};

exports.getDoctorMedicalRecords = async (req, res) => {
    try {
        const records = await MedicalRecord.find({ idDoctor: req.params.id });
        res.status(200).json(records);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching medical records', error });
    }
};

exports.getAllDoctors = async (req, res) => {
    try {
        // Trouve tous les médecins en projetant uniquement les champs nécessaires
        const doctors = await Doctor.find({}, 'Name FamilyName Specialite Tel Email');
        res.status(200).json(doctors);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching doctors', error });
    }
};
