const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3010;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB URI
const uri = "mongodb+srv://wafid:wafid@ouafid.aihn5iq.mongodb.net/RCW";

// Connect to MongoDB
mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Could not connect to MongoDB:', err));

// Room Schema and Model
const roomSchema = new mongoose.Schema({
  Number: Number,
  BedsNumber: Number,
});

const Room = mongoose.model('Room', roomSchema);

// Routes
app.get('/api/rooms', async (req, res) => {
  try {
    console.log('Request received for /api/rooms');
    const rooms = await Room.find({});
    console.log('Rooms found:', rooms);
    res.json(rooms);
  } catch (error) {
    console.error('Error fetching rooms:', error);
    res.status(500).json({ error: 'Failed to fetch rooms' });
  }
});

// New route to update beds number
app.post('/api/rooms/update', async (req, res) => {
  const { selectedRoomId, bedNumber } = req.body;
  console.log(bedNumber);
  console.log(selectedRoomId);
  
  try {
    console.log(`Request received to update room with ID: ${selectedRoomId}, BedNumber: ${bedNumber}`);
    const room = await Room.findById(selectedRoomId);

    if (!room) {
      return res.status(404).json({ error: 'Room not found' });
    }

    if (room.BedsNumber < bedNumber) {
      return res.status(400).json({ error: 'Not enough beds available' });
    }

    room.BedsNumber -= bedNumber;
    await room.save();

    console.log('Room updated:', room);
    res.json(room);
  } catch (error) {
    console.error('Error updating room:', error);
    res.status(500).json({ error: 'Failed to update room' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Client API running on port ${PORT}`);
});
