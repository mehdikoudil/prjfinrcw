const Client = require('../models/Client');
const MedicalRecord = require('../../medical-record-api/models/MedicalRecord');

exports.registerClient = async (req, res) => {
    try {
        // Extraire les données du corps de la requête
        const { Name,FamilyName,Adress,Tel,Email,Password  } = req.body;
        console.log(Name,FamilyName,Adress,Tel,Email,Password)
        // Vérifier que tous les champs nécessaires sont présents

        // Vérifier si le client avec cet email existe déjà
        const existingClient = await Client.findOne({ Email });
        if (existingClient) {
            return res.status(400).json({ message: 'Client with this email already exists' });
        }

        // Créer un nouveau client
        const client = new Client({ Name,FamilyName,Adress,Tel,Email,Password });
        await client.save();
        res.status(201).json(client);
    } catch (error) {
        console.error('Error registering client:', error);
        res.status(500).json({ message: 'Error registering client', error });
    }
};


exports.loginClient = async (req, res) => {
    try {
        const { Email, Password } = req.body;
        console.log("Les paramètres envoyées : ", Email, Password);

        // Rechercher le client par email
        const client = await Client.findOne({ Email });
        console.log(client);

        // Vérifier si le client existe
        if (!client) {
            return res.status(404).json({ message: 'Client not found' });
        }

        // Vérifier si le mot de passe correspond (assurez-vous que le mot de passe est haché)
        if (client.Password !== Password) {
            return res.status(401).json({ message: 'Incorrect password' });
        }

        // Répondre avec les détails du client
        res.status(200).json(client);
    } catch (error) {
        console.error('Error logging in:', error);
        res.status(500).json({ message: 'Error logging in', error: error.message });
    }
};

exports.getClientProfile = async (req, res) => {
    try {
        const client = await Client.findById(req.params.id);
        if (!client) {
            return res.status(404).json({ message: 'Client not found' });
        }
        res.status(200).json(client);
    } catch (error) {
        console.error('Error fetching client profile:', error);
        res.status(500).json({ message: 'Error fetching client profile', error });
    }
};

exports.updateClientProfile = async (req, res) => {
    try {
        const client = await Client.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!client) {
            return res.status(404).json({ message: 'Client not found' });
        }
        res.status(200).json(client);
    } catch (error) {
        console.error('Error updating client profile:', error);
        res.status(500).json({ message: 'Error updating client profile', error });
    }
};

exports.getClientMedicalRecords = async (req, res) => {
    try {
        const records = await MedicalRecord.find({ idClient: req.params.id });
        res.status(200).json(records);
    } catch (error) {
        console.error('Error fetching medical records:', error);
        res.status(500).json({ message: 'Error fetching medical records', error });
    }
};
