const mongoose = require('mongoose');

const clientSchema = new mongoose.Schema({
    Name: String,
    FamilyName: String,
    Adress : String,
    Tel: String,
    Email: String ,
    Password: String
});

module.exports = mongoose.model('Client', clientSchema);
