const express = require('express');
const clientController = require('../controllers/clientController');
const router = express.Router();

// Routes pour gérer les clients
router.post('/register', clientController.registerClient);
router.post('/login', clientController.loginClient);
router.get('/profile/:id', clientController.getClientProfile);
router.put('/profile/:id', clientController.updateClientProfile);
router.get('/medical-records/:id', clientController.getClientMedicalRecords);

module.exports = router;
