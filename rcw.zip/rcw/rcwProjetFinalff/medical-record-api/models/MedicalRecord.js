const mongoose = require('mongoose');

const medicalRecordSchema = new mongoose.Schema({
    idDoctor: { type: mongoose.Schema.Types.ObjectId, ref: 'Docter', required: true },
    idClient: { type: mongoose.Schema.Types.ObjectId, ref: 'Client', required: true },
    description: String,
    prescription: String,
    facture: Number,
    hospitalisation: Boolean
});

module.exports = mongoose.model('MedicalRecord', medicalRecordSchema);
