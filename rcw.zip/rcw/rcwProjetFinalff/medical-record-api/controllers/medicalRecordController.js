const MedicalRecord = require('../models/MedicalRecord');

exports.createMedicalRecord = async (req, res) => {
    try {
        const record = new MedicalRecord(req.body);
        await record.save();
        res.status(201).json(record);
    } catch (error) {
        res.status(500).json({ message: 'Error creating medical record', error });
    }
};

exports.createMedicalRecordWithoutAuth = async (req, res) => {
    try {
        const record = new MedicalRecord(req.body);
        console.log(record);
        
        await record.save();
        res.status(201).json(record);
    } catch (error) {
        res.status(500).json({ message: 'Error creating medical record', error });
    }
};

exports.getMedicalRecordsByClient = async (req, res) => {
    try {
        const records = await MedicalRecord.find({ idClient: req.params.clientId });
        res.status(200).json(records);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching medical records by client', error });
    }
};

exports.getMedicalRecordsByDoctor = async (req, res) => {
    try {
        const records = await MedicalRecord.find({ idDoctor: req.params.doctorId });
        res.status(200).json(records);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching medical records by doctor', error });
    }
};
