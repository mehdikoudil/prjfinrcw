const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
    try {
        const token = req.headers.authorization.split('Bearer ')[1];
        const decoded = jwt.verify(token, 'YOUR_SECRET_KEY');
        req.user = decoded; // Assurez-vous que le token contient les informations nécessaires
        next();
    } catch (error) {
        res.status(401).json({ message: "Authentication failed", error: error.message });
    }
};

module.exports = authMiddleware;
