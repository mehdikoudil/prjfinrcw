const express = require('express');
const medicalRecordController = require('../controllers/medicalRecordController');
const router = express.Router();

// Routes pour gérer les dossiers médicaux
router.post('/', medicalRecordController.createMedicalRecord);
router.post('/noauth', medicalRecordController.createMedicalRecordWithoutAuth);
router.get('/clients/:clientId', medicalRecordController.getMedicalRecordsByClient);
router.get('/doctors/:doctorId', medicalRecordController.getMedicalRecordsByDoctor);

module.exports = router;
