import React, { useEffect, useState } from 'react';
import { Text, View, ActivityIndicator, FlatList, StyleSheet, Button } from 'react-native';
import { RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import axios from 'axios';

const URL = '192.168.29.1'; // Remplacez par l'URL de votre serveur

type RootStackParamList = {
  HomePat: { user: { Name: string; FamilyName: string; Adress: string; Tel: string; Email: string; Password: string; Role: string; Specialite: string; _id: string } };
};

type HomePatRouteProp = RouteProp<RootStackParamList, 'HomePat'>;
type HomePatNavigationProp = StackNavigationProp<RootStackParamList, 'HomePat'>;

interface HomePatProps {
  route: HomePatRouteProp;
  navigation: HomePatNavigationProp;
}

interface Appointment {
  idDoctor: string;
  idClient: string;
  jour: Date;
  heure: Date;
  sujet: string;
  Status : string
}


const HomePat: React.FC<HomePatProps> = ({ route, navigation }) => {
  const { user } = route.params;

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAppointments = async () => {
    try {
      setLoading(true); // Mettre à jour l'état pour afficher le loader
      const response = await axios.get<Appointment[]>(`http://${URL}:3004/api/appointments/get`, {
        params: { clientID: user._id }
      });
      setAppointments(response.data);
      setLoading(false);
    
    } catch (error) {
      setError('Error fetching appointments');
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [user._id]);

  if (loading) {
    return <ActivityIndicator size="large" color="#0000ff" />;
  }

  if (error) {
    return <Text>{error}</Text>;
  }
  async function FindDocInfo(id: any) {
    try {
      // Envoyer une requête POST avec l'ID du docteur
      const response = await axios.post(`http://${URL}:3002/api/doctors/profile/:${ id }`);
      
      // Extraire les données de la réponse
      const data = response.data;
  
      // Afficher les données dans la console
      console.log(data);
  
      // Vous pouvez également retourner les données si nécessaire
      return data;
    } catch (error) {
      // Gérer les erreurs
      console.error('Error fetching doctor info:', error);
      throw error; // Re-throw l'erreur si vous voulez la gérer ailleurs
    }
  }

  return (
    <View style={styles.container}>
      <Button title="Refresh Appointments" onPress={fetchAppointments} color="#007bff" />
      <Text style={styles.header}>Appointments for {user.FamilyName} ,{user.Name}</Text>
      <FlatList
        data={appointments}
        keyExtractor={(item) => item.idClient} // Assurez-vous que vous avez un champ unique comme _id
        renderItem={({ item }) => (
          <View style={styles.appointmentContainer}>
            <Text style={styles.appointmentText}>Date: {new Date(item.jour).toDateString()}</Text>
            <Text style={styles.appointmentText}>Time: {new Date(item.heure).toLocaleTimeString()}</Text>
            <Text style={styles.appointmentText}>Subject: {item.sujet}</Text>
            <Text style={styles.appointmentText}>avec: {item.idDoctor}</Text>
            <Text style={styles.appointmentText}>Etat: {item.Status}</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  appointmentContainer: {
    padding: 15,
    marginVertical: 10,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
  },
  appointmentText: {
    fontSize: 16,
  },
});

export default HomePat;
