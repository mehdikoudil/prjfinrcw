import { StyleSheet, Text, View, Linking, TouchableOpacity } from 'react-native';

const AI = () => {
  const openStreamlitApp1 = () => {
    Linking.openURL('http://192.168.29.1:8501');
  };

  const openStreamlitApp2 = () => {
    Linking.openURL('http://192.168.29.1:8502');
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.button} onPress={openStreamlitApp1}>
        <Text style={styles.buttonText}>
          Open Medical Chatbot Diagnostic Assistant (PDF)
        </Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={openStreamlitApp2}>
        <Text style={styles.buttonText}>
          Open Medical Diagnostic Assistant
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default AI;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f8f9fa',
  },
  button: {
    backgroundColor: '#007bff',
    paddingVertical: 15,
    paddingHorizontal: 25,
    borderRadius: 5,
    marginVertical: 10,
    width: '80%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
