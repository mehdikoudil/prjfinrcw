import React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import { RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';

type RootStackParamList = {
  Profile: { user: { Name: string; FamilyName: string; Adress: string; Tel: string; Email: string; Password: string; Role: string; Specialite: string } };
};

type ProfileRouteProp = RouteProp<RootStackParamList, 'Profile'>;
type ProfileNavigationProp = StackNavigationProp<RootStackParamList, 'Profile'>;

interface ProfileProps {
  route: ProfileRouteProp;
  navigation: ProfileNavigationProp;
}

const Profile: React.FC<ProfileProps> = ({ route }) => {
  const { user } = route.params;

  return (
    <View style={styles.container}>
      <View style={styles.profileHeader}>
        {/* You can add a profile picture here */}
        <Image
          source={{ uri: 'https://via.placeholder.com/100' }} // Replace with actual user photo URL if available
          style={styles.profileImage}
        />
        <Text style={styles.name}>{user.Name} {user.FamilyName}</Text>
      </View>
      {user ? (
        <>
          <View style={styles.infoContainer}>
            <Text style={styles.label}>Email:</Text>
            <Text style={styles.value}>{user.Email}</Text>
          </View>
          {user.Role === 'Docter' ? (
            <View style={styles.infoContainer}>
              <Text style={styles.label}>Speciality:</Text>
              <Text style={styles.value}>{user.Specialite}</Text>
            </View>
          ) : (
            <View style={styles.infoContainer}>
              <Text style={styles.label}>Address:</Text>
              <Text style={styles.value}>{user.Adress}</Text>
            </View>
          )}
          <View style={styles.infoContainer}>
            <Text style={styles.label}>Phone:</Text>
            <Text style={styles.value}>{user.Tel}</Text>
          </View>
        </>
      ) : (
        <Text style={styles.error}>No data passed</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#e9ecef',
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
    borderWidth: 2,
    borderColor: '#adb5bd',
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#343a40',
  },
  infoContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#495057',
  },
  value: {
    fontSize: 16,
    color: '#212529',
  },
  error: {
    fontSize: 16,
    color: '#dc3545',
    textAlign: 'center',
    marginTop: 20,
  },
});

export default Profile;
