import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, Button, Platform, ScrollView, Alert } from 'react-native';
import axios from 'axios';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Picker } from '@react-native-picker/picker';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../_layout';

const URL = '192.168.29.1';
type AppointmentsNavigationProp = StackNavigationProp<RootStackParamList,"_layoutDoc">;

interface HospitalizationProps {
  route: any;
  navigation: AppointmentsNavigationProp;
}

interface Appointment {
  _id: string;
  idDoctor: string;
  idClient: string;
  jour: Date;
  heure: Date;
  sujet: string;
  Status: string;
}

interface Room {
  Number: number;
  BedsNumber: number;
  _id: string;
}

const Hospitalization: React.FC<HospitalizationProps> = ({ route,navigation }) => {
  const { Hospitalization } = route.params;
  const { appointment, Docter } = Hospitalization;
  const [prescription, setPrescription] = useState('');
  const [invoice, setInvoice] = useState('');
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [showRooms, setShowRooms] = useState(false);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);
  const [bedNumber, setBedNumber] = useState('');
  const [arrivalDate, setArrivalDate] = useState(new Date());
  const [departureDate, setDepartureDate] = useState(new Date());
  const [showArrivalDatePicker, setShowArrivalDatePicker] = useState(false);
  const [showDepartureDatePicker, setShowDepartureDatePicker] = useState(false);

  useEffect(() => {
    if (showRooms) {
      const fetchRooms = async () => {
        setLoading(true);
        try {
          console.log('Fetching rooms...');
          const response = await axios.get(`http://${URL}:3010/api/rooms`);
          console.log('Rooms fetched:', response.data);
          setRooms(response.data);
        } catch (error) {
          console.error('Error fetching rooms:', error);
          setError('Failed to fetch rooms');
        } finally {
          setLoading(false);
        }
      };

      fetchRooms();
    }
  }, [showRooms]);

  const handleCreateMedicalRecord = async () => {
    const Confirmation = {
      idDoctor: appointment.idDoctor,
      idClient: appointment.idClient,
      description: appointment.sujet,
      prescription,
      facture: invoice
    };

    try {
      await axios.post(`http://${URL}:3003/api/medical-records/noauth`, Confirmation);
      DeleteRVById(appointment)
      setSuccessMessage('Medical record created successfully!');
    } catch (error) {
      console.error('Something went wrong:', error);
      
    }
  };

  const handleHospitalization = () => {
    handleCreateMedicalRecord()
    setShowRooms(true);
  };

  const handleSubmit = async () => {

    const assignBed = {
      idDoctor: appointment.idDoctor,
      idCoctor: appointment.idDoctor,
      chambre: selectedRoomId,
      numLit: bedNumber,
      arrivee: arrivalDate,
      depart: departureDate,
      occupied: true
    }
    try {
      const bed = await axios.post(`http://${URL}:3005/api/beds`, assignBed);
      if (bed) {
        const BedUpdate = await axios.post(`http://${URL}:3010/api/rooms/update`, { selectedRoomId, bedNumber });
        if (BedUpdate) {
          navigation.navigate("_layoutDoc",{ user: Docter })
          setSuccessMessage('the bed has been assigned successfully!');
        }

      }

    } catch (error) {
      console.error('Something went wrong:', error);
      setSuccessMessage('Failed to create medical record.');
    }




  };

  const handleArrivalDateChange = (event: any, selectedDate: Date | undefined) => {
    setShowArrivalDatePicker(Platform.OS === 'ios');
    if (selectedDate) setArrivalDate(selectedDate);
  };

  const handleDepartureDateChange = (event: any, selectedDate: Date | undefined) => {
    setShowDepartureDatePicker(Platform.OS === 'ios');
    if (selectedDate) setDepartureDate(selectedDate);
  };
  
  const DeleteRVById= async (appointment:Appointment)=>{
    try {
      setLoading(true);
       const appointmentId = appointment._id
       
       
      const response = await axios.post<Appointment[]>(`http://${URL}:3004/api/appointments/delete`,{ appointmentId: appointment._id })
  }
 catch (error) {
      console.error('Something went wrong:', error);
      
    }
  }

  return (
    <ScrollView>
    <View style={styles.container}>
      {showRooms ? (
        <ScrollView>
          {loading ? (
            <Text style={styles.loadingText}>Loading...</Text>
          ) : error ? (
            <Text style={styles.errorText}>{error}</Text>
          ) : (
            <>
              <Text style={styles.label}> Choose a Room :</Text>
              <Picker
                selectedValue={selectedRoomId}
                onValueChange={(value) => setSelectedRoomId(value)}
                style={pickerSelectStyles.input}
              >
                {rooms.map(room => (
                  <Picker.Item
                    key={room._id}
                    label={`Room: ${room.Number}- Beds: ${room.BedsNumber}`}
                    value={room._id}
                  />
                ))}
              </Picker>
              <Text style={styles.label}> How Many Beds  :</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter bed number"
                value={bedNumber}
                onChangeText={(value) => setBedNumber(value)}
              />

              {(Platform.OS == "android" || Platform.OS == "ios") && (
                <View style={styles.datePickerContainer}>
                  <Text style={styles.label}>Arrival Date:</Text>
                  <Button title="Select Arrival Date" onPress={() => setShowArrivalDatePicker(true)} />
                  {showArrivalDatePicker && (
                    <DateTimePicker
                      testID="dateTimePicker"
                      value={arrivalDate}
                      mode="date"
                      display="default"
                      onChange={handleArrivalDateChange}
                    />

                  )}
                  <Text> {arrivalDate.toDateString()}</Text>
                </View>

              )}
              {(Platform.OS == "android" || Platform.OS == "ios") && (
                <View style={styles.datePickerContainer}>
                  <Text style={styles.label}>Departure Date:</Text>
                  <Button title="Select Departure Date" onPress={() => setShowDepartureDatePicker(true)} />
                  {showDepartureDatePicker && (
                    <DateTimePicker
                      testID="dateTimePicker"
                      value={departureDate}
                      mode="date"
                      display="default"
                      onChange={handleDepartureDateChange}
                    />
                  )}
                  <Text> {departureDate.toDateString()}</Text>
                </View>
              )
              }

              {/* Web Date Pickers */}
              {Platform.OS === 'web' && (
                <>
                  <View style={styles.datePickerContainer}>
                    <Text style={styles.label}>Arrival Date:</Text>
                    <input
                      type="date"
                      value={arrivalDate.toISOString().split('T')[0]}
                      onChange={(e) => setArrivalDate(new Date(e.target.value))}
                    />

                  </View>
                  <View style={styles.datePickerContainer}>
                    <Text style={styles.label}>Departure Date:</Text>
                    <input
                      type="date"
                      value={departureDate.toISOString().split('T')[0]}
                      onChange={(e) => setDepartureDate(new Date(e.target.value))}
                    />

                  </View>
                </>
              )}

              <TouchableOpacity style={[styles.button, styles.greenButton]} onPress={handleSubmit}>
                <Text style={styles.buttonText}>Submit</Text>
              </TouchableOpacity>
            </>
          )}
        </ScrollView>
      ) : (
        <>
          <Text style={styles.header}>Create Medical Record</Text>
          <View style={styles.detailsContainer}>
            <Text style={styles.label}>Doctor:</Text>
            <Text style={styles.value}>{Docter.Name} {Docter.FamilyName}</Text>
          </View>
          <View style={styles.detailsContainer}>
            <Text style={styles.label}>Client Name:</Text>
            <Text style={styles.value}>{appointment.idClient}</Text>
          </View>
          <View style={styles.detailsContainer}>
            <Text style={styles.label}>Date:</Text>
            <Text style={styles.value}>{new Date(appointment.jour).toDateString()}</Text>
          </View>
          <View style={styles.detailsContainer}>
            <Text style={styles.label}>Time:</Text>
            <Text style={styles.value}>{new Date(appointment.heure).toLocaleTimeString()}</Text>
          </View>
          <View style={styles.detailsContainer}>
            <Text style={styles.label}>Reason:</Text>
            <Text style={styles.value}>{appointment.sujet}</Text>
          </View>
          <TextInput
            style={styles.input}
            placeholder="Enter prescription details"
            value={prescription}
            onChangeText={setPrescription}
          />
          <TextInput
            style={styles.input}
            placeholder="Enter invoice details"
            value={invoice}
            onChangeText={setInvoice}
          />
          {successMessage && (
            <Text style={styles.successMessage}>{successMessage}</Text>
          )}
          <View style={styles.buttonsContainer}>
            <TouchableOpacity style={[styles.button, styles.greenButton]} onPress={handleCreateMedicalRecord}>
              <Text style={styles.buttonText}>Create Medical Record</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.button, styles.orangeButton]} onPress={handleHospitalization}>
              <Text style={styles.buttonText}>Hospitalization</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </View>
    </ScrollView>
  );
};

const pickerSelectStyles = StyleSheet.create({
  input: {
    fontSize: 16,
    paddingHorizontal: 10,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    color: '#000',
    paddingRight: 30,
    marginTop: 20,
    marginBottom: 20
  },
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  detailsContainer: {
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 1,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 15,
    marginBottom: 15
  },
  value: {
    fontSize: 16,
    color: '#666',
  },
  input: {
    height: 40,
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 15,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  button: {
    flex: 1,
    marginHorizontal: 5,
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  greenButton: {
    backgroundColor: '#28a745',
  },
  orangeButton: {
    backgroundColor: '#ffa500',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  successMessage: {
    marginTop: 15,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#28a745',
    textAlign: 'center',
  },
  loadingText: {
    fontSize: 18,
    textAlign: 'center',
    marginTop: 20,
  },
  errorText: {
    fontSize: 18,
    color: 'red',
    textAlign: 'center',
    marginTop: 20,
  },
  datePickerContainer: {
    marginBottom: 20,
  },
});

export default Hospitalization;
