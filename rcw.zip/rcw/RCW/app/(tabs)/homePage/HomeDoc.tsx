import React, { useEffect, useState } from 'react';
import { Text, View, ActivityIndicator, FlatList, StyleSheet, Button } from 'react-native';
import { RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import axios from 'axios';

type HomeDocScreenNavigationProp = StackNavigationProp<RootStackParamList, 'HomeDoc'>;

const URL = '192.168.29.1'; // Remplacez par l'URL de votre serveur

type RootStackParamList = {
  HomeDoc: { user: { Name: string; FamilyName: string; Adress: string; Tel: string; Email: string; Password: string; Role: string; Specialite: string; _id: string } };
};

type HomeDocRouteProp = RouteProp<RootStackParamList, 'HomeDoc'>;
type HomeDocNavigationProp = StackNavigationProp<RootStackParamList, 'HomeDoc'>;

interface HomeDocProps {
  route: HomeDocRouteProp;
  navigation: HomeDocNavigationProp;
}

interface Appointment {
  _id: string;
  idDoctor: string;
  idClient: string;
  jour: Date;
  heure: Date;
  sujet: string;
  Status: string;
}

const HomeDoc: React.FC<HomeDocProps> = ({ route, navigation }) => {
  const { user } = route.params;

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAppointments = async () => {
    try {
      setLoading(true);
      const response = await axios.get<Appointment[]>(`http://${URL}:3004/api/appointments/get`, {
        params: { clientID: user._id, Role: user.Role }
      });
      // Filtrer les rendez-vous dont le statut est différent de "Confirmed"
      const filteredAppointments = response.data.filter(appointment => appointment.Status !== "Confirmed");
      setAppointments(filteredAppointments);
      setLoading(false);
    } catch (error) {
      setError('Error fetching appointments');
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [user._id]);

  if (loading) {
    return <ActivityIndicator size="large" color="#0000ff" />;
  }

  if (error) {
    return <Text>{error}</Text>;
  }

  const UpdateRV = async (item: Appointment) => {
    const id = item._id;
    console.log(id);
    try {
        const response = await axios.post(`http://${URL}:3004/api/appointments/update`, { appointmentId: id });
        console.log('Response:', response.data);
    } catch (error) {
        console.error('Error updating appointment:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Button title="Refresh Appointments" onPress={fetchAppointments} color="#007bff" />
      <Text style={styles.header}>To Confirm for Dr: {user.FamilyName}, {user.Name}</Text>
      <FlatList
        data={appointments}
        keyExtractor={(item) => item._id} // Assurez-vous que vous avez un champ unique comme _id
        renderItem={({ item }) => (
          <View style={styles.appointmentContainer}>
            <Text style={styles.appointmentText}>Date: {new Date(item.jour).toDateString()}</Text>
            <Text style={styles.appointmentText}>Time: {new Date(item.heure).toLocaleTimeString()}</Text>
            <Text style={styles.appointmentText}>Reason: {item.sujet}</Text>
            <Text style={styles.appointmentText}>Client Name: {item.idClient}</Text>
            
            <Button
              title="Confirme"
              onPress={() => UpdateRV(item)}
              color="#28a745"
            />
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  appointmentContainer: {
    padding: 15,
    marginVertical: 10,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
  },
  appointmentText: {
    fontSize: 16,
  },
});

export default HomeDoc;
