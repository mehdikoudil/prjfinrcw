import React, { useEffect, useState } from 'react';
import { StyleSheet, View, Text, ActivityIndicator, Button, TextInput, Platform, TouchableOpacity, Alert, ScrollView } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import axios from 'axios';
import DateTimePicker from '@react-native-community/datetimepicker';
const URL = '192.168.29.1';
import { RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';


type RootStackParamList = {
  RV: { user: { Name :string,FamilyName :string,Adress :string,Tel :string,Email:string,Password :string,Role:String,Specialite:String ,_id:String } };
};
    
type RVRouteProp = RouteProp<RootStackParamList, 'RV'>;
type RVNavigationProp = StackNavigationProp<RootStackParamList, 'RV'>;

interface RVProps {
  route: RVRouteProp;
  navigation: RVNavigationProp;
}

interface Doctor {
  _id: string;
  Name: string;
  FamilyName: string;
  Specialite: string;
  Tel: string;
  Email: string;
}

const RV: React.FC<RVProps> = ({ route, navigation }) => {
  const { user } = route.params;
  const [serverError, setServerError] = useState('');
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('');
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [date, setDate] = useState<Date>(new Date());
  const [time, setTime] = useState<Date>(new Date());
  const [showDatePicker, setShowDatePicker] = useState<boolean>(false);
  const [showTimePicker, setShowTimePicker] = useState<boolean>(false);
  const [reason, setReason] = useState<string>('');

  const fetchDoctors = async () => {
    try {
      setLoading(true);
      const response = await axios.get<Doctor[]>(`http://${URL}:3002/api/doctors/all`);
      setDoctors(response.data);
      setLoading(false);
    } catch (error) {
      setError('Error fetching doctors');
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDoctors();
  }, []);

  useEffect(() => {
    if (selectedDoctorId) {
      const doctor = doctors.find(doc => doc._id === selectedDoctorId);
      setSelectedDoctor(doctor || null);
    }
  }, [selectedDoctorId, doctors]);

  const handleRefresh = () => {
    fetchDoctors();
  };

  const onDateChange = (event: any, selectedDate: Date | undefined) => {
    const currentDate = selectedDate || date;
    setShowDatePicker(Platform.OS === 'ios');
    setDate(currentDate);
  };

  const onTimeChange = (event: any, selectedTime: Date | undefined) => {
    const currentTime = selectedTime || time;
    setShowTimePicker(Platform.OS === 'ios');
    setTime(currentTime);
  };

  const handleDateChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setDate(new Date(event.target.value));
  };

  const handleTimeChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const [hours, minutes] = event.target.value.split(':').map(Number);
    const newTime = new Date(time);
    newTime.setHours(hours);
    newTime.setMinutes(minutes);
    setTime(newTime);
  };

  const handleSubmit = async () => {
    if (selectedDoctorId && date && time && reason) {
      // console.log('Doctor ID:', selectedDoctorId);
      // console.log('Date:', date.toDateString());
      // console.log('Time:', time.toLocaleTimeString());
      // console.log('Reason for Visit:', reason);
      // console.log(user._id);
      Alert.alert('appointment Confirmed')

      const appointment={
        idDoctor:selectedDoctorId,
        idClient:user._id,
        jour:date,
        heure:time,
        sujet :reason,
        Status:" not Confirmed"


      }
      
      try {
        const response = await axios.post(`http://${URL}:3004/api/appointments/create`, appointment);
        const data = response.data;
        console.log(data);
        
      } 
      catch (error) {
         setServerError("Une erreur est survenue. Veuillez réessayer.");
       }
      
    } else {
      console.log('Please fill out all fields');
    }
  };

  if (loading) {
    return <ActivityIndicator size="large" color="#0000ff" />;
  }

  if (error) {
    return <Text>{error}</Text>;
  }

  return (
    <ScrollView>
    <View style={styles.container}>
      <Text style={styles.label}>Select a Doctor:</Text>
      <Picker
        selectedValue={selectedDoctorId}
        onValueChange={(itemValue) => setSelectedDoctorId(itemValue)}
        style={styles.picker}
      >
        <Picker.Item label="Select a doctor" value="" />
        {doctors.map((doctor) => (
          <Picker.Item
            key={doctor._id}
            label={`${doctor.Name} ${doctor.FamilyName} (${doctor.Specialite})`}
            value={doctor._id}
          />
        ))}
      </Picker>

      <TouchableOpacity style={styles.refreshButton} onPress={handleRefresh}>
        <Text style={styles.refreshButtonText}>Refresh Doctors</Text>
      </TouchableOpacity>

      {selectedDoctor && (
        <View style={styles.detailsContainer}>
          <Text style={styles.detailsText}>Phone: {selectedDoctor.Tel}</Text>
          <Text style={styles.detailsText}>Email: {selectedDoctor.Email}</Text>
        </View>
      )}

      {Platform.OS === 'web' && (
        <>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Date:</Text>
            <input
              type="date"
              value={date.toISOString().split('T')[0]}
              onChange={handleDateChange}
              style={styles.dateTimePicker}
            />
            <Text>{date.toDateString()}</Text>
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Time:</Text>
            <input
              type="time"
              value={time.toTimeString().slice(0, 5)}
              onChange={handleTimeChange}
              style={styles.dateTimePicker}
            />
            <Text>{time.toLocaleTimeString()}</Text>
          </View>
        </>
      )}

      {(Platform.OS === 'android' || Platform.OS === 'ios') && (
        <>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Date:</Text>
            <Button title="Select Date" onPress={() => setShowDatePicker(true)} />
            {showDatePicker && (
              <DateTimePicker
                testID="dateTimePicker"
                value={date}
                mode="date"
                display="default"
                onChange={onDateChange}
              />
            )}
            <Text>{date.toDateString()}</Text>
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Time:</Text>
            <Button title="Select Time" onPress={() => setShowTimePicker(true)} />
            {showTimePicker && (
              <DateTimePicker
                testID="dateTimePicker"
                value={time}
                mode="time"
                display="default"
                onChange={onTimeChange}
              />
            )}
            <Text>{time.toLocaleTimeString()}</Text>
          </View>
        </>
      )}

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Reason for Visit:</Text>
        <TextInput
          style={styles.textInput}
          placeholder="Enter reason here"
          value={reason}
          onChangeText={setReason}
        />
      </View>

      <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
        <Text style={styles.submitButtonText}>Submit</Text>
      </TouchableOpacity>
    </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  label: {
    fontSize: 18,
    marginBottom: 10,
  },
  picker: {
    height: 50,
    width: '100%',
  },
  detailsContainer: {
    marginTop: 20,
  },
  detailsText: {
    fontSize: 16,
  },
  inputContainer: {
    marginTop: 20,
  },
  textInput: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 10,
    marginTop: 10,
  },
  dateTimePicker: {
    width: '100%',
    height: 40,
    marginTop: 10,
  },
  refreshButton: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#007bff',
    borderRadius: 5,
  },
  refreshButtonText: {
    color: '#fff',
    textAlign: 'center',
    fontSize: 16,
  },
  submitButton: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#28a745',
    borderRadius: 5,
  },
  submitButtonText: {
    color: '#fff',
    textAlign: 'center',
    fontSize: 16,
  },
});

export default RV;
