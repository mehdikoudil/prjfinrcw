import { Platform, StyleSheet, View } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { RouteProp } from '@react-navigation/native';
import { StackActions } from '@react-navigation/native'; // Correct import for StackActions
import AI from './AI';
import Profile from './Profile';
import RV from './RV';
import HomePat from './HomePat';
import { TabBarIcon } from '@/components/navigation/TabBarIcon'; // Assurez-vous d'avoir cette importation
import HomeDoc from './HomeDoc';
import Appointments from './Appointments';


// Définir les types pour les paramètres des onglets
type RootTabParamList = {
    HomeDoc: { user: { lastName: string; name: string; email: string; Role: string } };
    AI: undefined;
    Profile: undefined;
    RV: undefined;
    Appointments: undefined;
};

// Définir les types pour la navigation et les routes
type LayoutRouteProp = RouteProp<RootTabParamList, 'HomeDoc'>;
type LayoutNavigationProp = BottomTabNavigationProp<RootTabParamList, 'HomeDoc'>;

interface LayoutProps {
    route: LayoutRouteProp;
    navigation: LayoutNavigationProp;
}

const Tab = createBottomTabNavigator<RootTabParamList>();

const _layoutDoc: React.FC<LayoutProps> = ({ route, navigation }) => {
    const { user } = route.params;
    console.log(user);

    const handleSignOut = () => {
        navigation.dispatch(StackActions.replace('Acceuil')); // Assurez-vous que 'Acceuil' est un écran valide
    };

    return (
        <View style={{ flex: 1 }}>
            <Tab.Navigator
                initialRouteName={user.Role === "Docter" ? "HomeDoc" : "HomePat"}
                screenOptions={{
                    tabBarActiveTintColor: 'blue', // Exemple de couleur active
                    tabBarInactiveTintColor: 'gray', // Exemple de couleur inactive
                    tabBarStyle: { backgroundColor: 'white' }, // Exemple de style de la barre de tabulation
                }}
            >
                {user.Role === "Docter" ? (
                    <Tab.Screen
                        name="HomeDoc"
                        component={HomeDoc}
                        options={{
                            tabBarLabel: 'Home',
                            tabBarIcon: ({ color, focused }) => (
                                <TabBarIcon name={focused ? 'home' : 'home-outline'} color={color} />
                            ),
                        }}
                        initialParams={{ user }}
                    />

                ) : (
                    <Tab.Screen
                        name="HomePat"
                        component={HomePat}
                        options={{
                            tabBarLabel: 'Home',
                            tabBarIcon: ({ color, focused }) => (
                                <TabBarIcon name={focused ? 'home' : 'home-outline'} color={color} />
                            ),
                        }}
                        initialParams={{ user }}
                    />
                )}

                <Tab.Screen
                    name="AI"
                    component={AI}
                    options={{
                        tabBarLabel: 'AI',
                        tabBarIcon: ({ color, focused }) => (
                            <TabBarIcon name={focused ? 'code-slash' : 'code-slash-outline'} color={color} />
                        ),
                    }}
                />

                {user.Role !== "Docter" && (
                    <Tab.Screen
                        name="RV"
                        component={RV}
                        options={{
                            tabBarLabel: 'RV',
                            tabBarIcon: ({ color, focused }) => (
                                <TabBarIcon name={focused ? 'star' : 'star-outline'} color={color} />
                            ),
                        }}
                        initialParams={{ user }}
                    />
                )}


                {user.Role == "Docter" && (
                    <Tab.Screen
                        name="Appointments"
                        component={Appointments}
                        options={{
                            tabBarLabel: 'Appointments',
                            tabBarIcon: ({ color, focused }) => (
                                <TabBarIcon name={focused ? 'star' : 'star-outline'} color={color} />
                            ),
                        }}
                        initialParams={{ user }}
                    />
                )}
                <Tab.Screen
                    name="Profile"
                    component={Profile}
                    options={{
                        tabBarLabel: 'Profile',
                        tabBarIcon: ({ color, focused }) => (
                            <TabBarIcon name={focused ? 'person' : 'person-outline'} color={color} />
                        ),
                    }}
                    initialParams={{ user }}
                />

                <Tab.Screen
                    name="SignOut"
                    component={() => null}
                    options={{
                        tabBarLabel: 'Sign out',
                    }}
                    listeners={{
                        tabPress: e => {
                            e.preventDefault();
                            handleSignOut();
                        },
                    }}
                />
            </Tab.Navigator>
        </View>
    );
};

export default _layoutDoc;

const styles = StyleSheet.create({});
