import React, { useEffect, useState } from 'react';
import { Text, View, ActivityIndicator, FlatList, StyleSheet, Button } from 'react-native';
import { RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import axios from 'axios';

const URL = '192.168.29.1'; // Remplacez par l'URL de votre serveur

type RootStackParamList = {
  Appointments: { user: { Name: string; FamilyName: string; Adress: string; Tel: string; Email: string; Password: string; Role: string; Specialite: string; _id: string } };
  Hospitalization: { Hospitalization: { appointment: Appointment; Docter: { Name: string; FamilyName: string; Adress: string; Tel: string; Email: string; Password: string; Role: string; Specialite: string; _id: string } } };
};



type AppointmentsRouteProp = RouteProp<RootStackParamList, 'Appointments'>;
type AppointmentsNavigationProp = StackNavigationProp<RootStackParamList, 'Appointments'>;

interface AppointmentsProps {
  route: AppointmentsRouteProp;
  navigation: AppointmentsNavigationProp;
}

interface Appointment {
  _id: string;
  idDoctor: string;
  idClient: string;
  jour: Date;
  heure: Date;
  sujet: string;
  Status: string;
}

const Appointments: React.FC<AppointmentsProps> = ({ route, navigation }) => {
  const { user } = route.params;

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAppointments = async () => {
    try {
      setLoading(true);
      const response = await axios.get<Appointment[]>(`http://${URL}:3004/api/appointments/get`, {
        params: { clientID: user._id, Role: user.Role }
      });
      const filteredAppointments = response.data.filter(appointment => appointment.Status === "Confirmed");
      setAppointments(filteredAppointments);
      setLoading(false);
    } catch (error) {
      setError('Error fetching appointments');
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [user._id]);

  if (loading) {
    return <ActivityIndicator size="large" color="#0000ff" />;
  }

  if (error) {
    return <Text>{error}</Text>;
  }

  const RvDetails = (item: Appointment) => {
    const Hospitalization = {
      appointment: item,
      Docter: user
    };
    
    navigation.navigate('Hospitalization', { Hospitalization });
  };
  

  return (
    <View style={styles.container}>
      <Button title="Refresh Appointments" onPress={fetchAppointments} color="#007bff" />
      <Text style={styles.header}>Confirmed Appointments for Dr.  : {user.FamilyName}, {user.Name}</Text>
      <FlatList
        data={appointments}
        keyExtractor={(item) => item._id} 
        renderItem={({ item }) => (
          <View style={styles.appointmentContainer}>
            <Text style={styles.appointmentText}>Date: {new Date(item.jour).toDateString()}</Text>
            <Text style={styles.appointmentText}>Time: {new Date(item.heure).toLocaleTimeString()}</Text>
            <Text style={styles.appointmentText}>Reason: {item.sujet}</Text>
            <Text style={styles.appointmentText}>Client Name: {item.idClient}</Text>
            
            <Button
              title="create medical record"
              onPress={() => RvDetails(item)}
              color="#ff0000"
            />
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  appointmentContainer: {
    padding: 15,
    marginVertical: 10,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
  },
  appointmentText: {
    fontSize: 16,
  },
});

export default Appointments;
