import React from 'react';
import { StyleSheet, Text, View, ImageBackground, Button } from 'react-native';

export default function Index() {
  return (
    <View>
      <Text> index level 1</Text>
     
    </View>
  );
}


