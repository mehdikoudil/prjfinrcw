import React, { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import Email from '@/components/src/docter/Sign_in/Email';
import PassWord from '@/components/src/docter/Sign_in/PassWord';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from './_layout'; // Assurez-vous d'importer le type RootStackParamList depuis votre fichier _layout.tsx
import { useNavigation } from '@react-navigation/native';
import axios from 'axios';

const URL='192.168.29.1'
type SignIn_DocterScreenNavigationProp = StackNavigationProp<RootStackParamList, 'SignIn_Docter'>;

const SignIn_Docter: React.FC = () => {
  const url='192.168.140.59'
  const navigation = useNavigation<SignIn_DocterScreenNavigationProp>();

  const [serverError, setServerError] = useState('');
  const [inputstate, setinputstate] = useState({
    email: '',
    password: '',
  });

  const validateFields = () => {
    if (!inputstate.email || !inputstate.password) {
      setServerError('Please fill in both fields.');
      return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!validateFields()) {
      return;
    }

    const docter = {
      Password: inputstate.password,
      Email: inputstate.email
    };
    
    
    //  Exemple de requête à décommenter lorsque vous avez une API
     try {
      const response = await axios.post(`http://${URL}:3002/api/doctors/login`, docter);
      const data = response.data;
      console.log(data);
      navigation.navigate('_layoutDoc', { user: data })
    } catch (error) {
       setServerError("Une erreur est survenue. Veuillez réessayer.");
     }
    
  };
  const Connecte = async () =>{
    const data={
      name:"ouafid",
      lastName:"habchi",
      email:"habchi@",
    }
    // navigation.navigate('_layoutDoc', { user: data })

   } 

  return (
    <View style={styles.container}>
      <Email inputstate={inputstate} setinputstate={setinputstate} />
      <PassWord inputstate={inputstate} setinputstate={setinputstate} />
      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Sign In</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.signupButton} onPress={() => {navigation.navigate('SignUP_Docter')}}>
        <Text style={styles.buttonText}>Create an Account</Text>
      </TouchableOpacity>
      {serverError ? <Text style={styles.errorText}>{serverError}</Text> : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginVertical: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  signupButton: {
    backgroundColor: '#6C757D',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  errorText: {
    color: 'red',
    marginTop: 10,
    textAlign: 'center',
  },
});

export default SignIn_Docter;
